package com.cg.session.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/session1")
public class HttpsessionServlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public HttpsessionServlet1() {
		super();

	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		String user = request.getParameter("userName");
		String post = request.getParameter("userPost");
		out.print("Welcome " + user + "Your Post is " + post);
		// creating session object
		out.print("<br/>");
		//
		HttpSession session = request.getSession();
		// getting session
		// session Id is always a string and session id would be same for the whole application
		String sessionId = session.getId();
		out.print("Session Id for user is " + sessionId);
		out.print("<br/>");
		out.print("Session Id for post is " + sessionId);
		out.print("<br/>");
		session.setAttribute("uname", user);
		session.setAttribute("upost", post);
		out.print("<a href ='session2'>See your Detail</a>");
		out.close();
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		 doGet(request, response);
	}

}
