package com.cg.session.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/session2")
public class HttpSessionServlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public HttpSessionServlet2() {
		super();

	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession(false);
		// false means whatever the session is created i want that session which
		// is by default
		String n = (String) session.getAttribute("uname");
		String p = (String) session.getAttribute("upost");
		// getattribute always return object, this concept is called narrowing
		out.print("Hello " + n + " Your post is " + p);
		out.print("<br/>");
		String sessionId = session.getId();

		out.print("session Id for user is " + sessionId);
		out.print("<br/>");
		out.print("session Id for post is " + sessionId);
		out.close();
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
