package com.cg.session.cookies;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CookiesServlet1
 */
@WebServlet("/cookies1")
public class CookiesServlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public CookiesServlet1() {
		super();

	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		String n = request.getParameter("userName");
		String post = request.getParameter("userPost");
		out.print("Welcome " + n + "Your Post is " + post);
		out.print("<br/>");
		Cookie ck = new Cookie("uname", n);// creating cookie object
		ck.setMaxAge(2);//to set maximum age of cookie -1 means never die, 0 means create and die, 1means 1 second
		Cookie ck1 = new Cookie("upost", post);
		response.addCookie(ck);// adding cookie in the response
		response.addCookie(ck1);
		// creating submit button
		out.print("<form action='cookie2' method='post'>");
		out.print("<input type='submit'>");
		out.print("</form>");
	}

}
