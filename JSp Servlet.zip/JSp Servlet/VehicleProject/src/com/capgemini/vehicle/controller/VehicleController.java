package com.capgemini.vehicle.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.vehicle.dto.Vehicle;
import com.capgemini.vehicle.exception.CustomException;
import com.capgemini.vehicle.service.IVehicleService;
import com.capgemini.vehicle.service.VehicleServiceImpl;

/**
 * Servlet implementation class BookController
 * Acting as front controller. Where all requests are dispatched from this controller
 */
@WebServlet("/VehicleController")
public class VehicleController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String operation = request.getParameter("action");
		PrintWriter pw = response.getWriter();
		RequestDispatcher view = null;
		IVehicleService service = new VehicleServiceImpl();
		if(operation !=null && "delete".equals(operation))
		{
			view = request.getRequestDispatcher("deleteVehicle.html");
			view.forward(request, response);
		}
		if(operation !=null && "Delete Vehicle".equals(operation))
		{
			int delete=Integer.parseInt(request.getParameter("vehicleid"));
			Vehicle vehicle = new Vehicle();
			vehicle.setVehicleId(delete);
			try{
				int records = service.deleteVehicle(vehicle);
				if(records !=0)
				{
					view = request.getRequestDispatcher("successDelete.html");
					view.forward(request, response);
				}
				else
				{
					pw.println("Deleting Vehicle details failed");
					view = request.getRequestDispatcher("error.html");
					view.include(request, response);
				}
			}
			catch(CustomException e)
			{
				pw.println("Error while deleting vehicle details");
				view = request.getRequestDispatcher("error.html");
				view.include(request, response);
			}
			
		}
		if (operation != null && "add".equals(operation)) {
			view = request.getRequestDispatcher("addVehicle.html");
			view.forward(request, response);
		}
		if (operation != null && "Append Vehicle".equals(operation)) {
			String Name = request.getParameter("vehiclename");
			LocalDate Date = LocalDate.parse(request
					.getParameter("purchasedate"));
			float Price = Float.parseFloat(request
					.getParameter("vehicleprice"));
			String city = request.getParameter("city");
			Vehicle vehicle = new Vehicle();
			vehicle.setVehicle_name(Name);
			vehicle.setPurchase_date(Date); 
			vehicle.setVehiclePrice(Price);
			vehicle.setCity(city);
			try {
				int records = service.insertVehicle(vehicle);
				if (records != 0) {
					view = request.getRequestDispatcher("success.html");
					view.forward(request, response);
				} else {
					pw.println("Inserting Vehicle details failed");
					view = request.getRequestDispatcher("error.html");
					view.include(request, response);
				}
			} catch (CustomException e) {
				pw.println("Error while inserting vehicle details");
				view = request.getRequestDispatcher("error.html");
				view.include(request, response);
			}
		} if(operation != null && "view".equals(operation)) {
			try {
				ArrayList<Vehicle> vehicleList = service.showVehicles();
				if (vehicleList != null) {
					Iterator<Vehicle> VehicleIterator = vehicleList.iterator();
					pw.println("<body>");
					pw.println("<table border='1'>");
					pw.println("<tr>");
					pw.println("<th>Vehicle Id</th>");
					pw.println("<th>Vehicle Name</th>");
					pw.println("<th>Vehicle Purchase Date</th>");
					pw.println("<th>Vehicle Price</th>");
					pw.println("<th>City</th>");
					pw.println("</tr>");
					while(VehicleIterator.hasNext()) {
						Vehicle veh = VehicleIterator.next();
						pw.println("<tr>");
						pw.println("<td>"+veh.getVehicleId()+"</td>");
						pw.println("<td>"+veh.getVehicle_name()+"</td>");
						pw.println("<td>"+veh.getPurchase_date()+"</td>");
						pw.println("<td>"+veh.getVehiclePrice()+"</td>");
						pw.println("<td>"+veh.getCity()+"</td>");
						pw.println("</tr>");
					}
					pw.println("</table>");
					pw.println("<a href='Index.html'>Go Back to Home</a>");
					pw.println("</body>");
				} else {
					pw.println("Fetching Vehicle details failed");
					view = request.getRequestDispatcher("error.html");
					view.include(request, response);
				}
			} catch (CustomException e) {
				pw.println("Error while fetching vehicle details");
				view = request.getRequestDispatcher("error.html");
				view.include(request, response);
			}
		}
		
	}

}
