package com.capgemini.vehicle.service;

import java.util.ArrayList;

import com.capgemini.vehicle.dto.Vehicle;
import com.capgemini.vehicle.exception.CustomException;

public interface IVehicleService {
	public int insertVehicle(Vehicle vehicle) throws CustomException;
	public ArrayList<Vehicle> showVehicles() throws CustomException;
	public int deleteVehicle(Vehicle vehicle) throws CustomException;
}
