package com.capgemini.vehicle.service;

import java.util.ArrayList;

import com.capgemini.vehicle.dao.IVehicleDAO;
import com.capgemini.vehicle.dao.VehicleDAOImpl;
import com.capgemini.vehicle.dto.Vehicle;
import com.capgemini.vehicle.exception.CustomException;
/*
 * Service layer - dispatching all calls to database layer
 */
public class VehicleServiceImpl implements IVehicleService {

	IVehicleDAO vehicleDAO;

	public VehicleServiceImpl() {
		 vehicleDAO = new VehicleDAOImpl();
	}

	@Override
	public int insertVehicle(Vehicle vehicle) throws CustomException {
		 
		return vehicleDAO.insertVehicle(vehicle);
	}

	@Override
	public ArrayList<Vehicle> showVehicles() throws CustomException {
		 
		return vehicleDAO.showVehicles() ;
	}

	@Override
	public int deleteVehicle(Vehicle vehicle) throws CustomException {
		 
		return vehicleDAO.deleteVehicle(vehicle);
	}

	 

}
