package com.capgemini.vehicle.dto;

import java.time.LocalDate;

public class Vehicle {
	private int vehicleId;
	private String vehicle_name;
	private LocalDate purchase_date;
	private float vehiclePrice;
	private String city;
	
	public Vehicle() {
		super();
		 
	}

	public Vehicle(int vehicleId, String vehicle_name, LocalDate purchase_date,
			float vehiclePrice, String city) {
		super();
		this.vehicleId = vehicleId;
		this.vehicle_name = vehicle_name;
		this.purchase_date = purchase_date;
		this.vehiclePrice = vehiclePrice;
		this.city = city;
	}

	public int getVehicleId() {
		return vehicleId;
	}

	public void setVehicleId(int vehicleId) {
		this.vehicleId = vehicleId;
	}

	public String getVehicle_name() {
		return vehicle_name;
	}

	public void setVehicle_name(String vehicle_name) {
		this.vehicle_name = vehicle_name;
	}

	public LocalDate getPurchase_date() {
		return purchase_date;
	}

	public void setPurchase_date(LocalDate purchase_date) {
		this.purchase_date = purchase_date;
	}

	public float getVehiclePrice() {
		return vehiclePrice;
	}

	public void setVehiclePrice(float vehiclePrice) {
		this.vehiclePrice = vehiclePrice;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}
	
	 
}
