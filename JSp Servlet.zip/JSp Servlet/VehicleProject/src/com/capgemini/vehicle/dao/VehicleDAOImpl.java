package com.capgemini.vehicle.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.capgemini.vehicle.dto.Vehicle;
import com.capgemini.vehicle.exception.CustomException;
import com.capgemini.vehicle.util.DBUtil;

/*
 * Database class - with all the database queries
 */
public class VehicleDAOImpl implements IVehicleDAO {

	Connection connection = null;
	Statement statement = null;
	ResultSet rsSet = null;
	PreparedStatement preparedStatement = null;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.igate.book.dao.IBookDAO#insertBook(com.igate.book.dto.Book) Code
	 * to insert book record in table, returning int- specifying number of
	 * records that are inserted successfully
	 */


	@Override
	public ArrayList<Vehicle> showVehicles() throws CustomException {
		ArrayList<Vehicle> VehicleList = new ArrayList<Vehicle>();
		connection = DBUtil.obtainConnection();
		String sql = "SELECT vehicleId,vehicle_name,purchase_date,price,city FROM vehicle";
		try {
			statement = connection.createStatement();
			rsSet = statement.executeQuery(sql);
			while (rsSet.next()) {
				Vehicle book = new Vehicle();
				book.setVehicleId(rsSet.getInt("vehicleId"));
				book.setVehicle_name(rsSet.getString("vehicle_name"));
				book.setPurchase_date(rsSet.getDate("purchase_date")
						.toLocalDate());
				book.setVehiclePrice(rsSet.getFloat("price"));
				book.setCity(rsSet.getString("city"));

				VehicleList.add(book);
			}
		} catch (SQLException e) {
			throw new CustomException("Error while fetching values::"
					+ e.getMessage());
		}
		return VehicleList;

	}

	@Override
	public int insertVehicle(Vehicle vehicle) throws CustomException {
		connection = DBUtil.obtainConnection();
		String sql = "INSERT INTO VEHICLE VALUES(vehicle_seq.nextval,?,?,?,?)";
		int recordInserted = 0;
		try {
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, vehicle.getVehicle_name());
			preparedStatement.setDate(2,
					java.sql.Date.valueOf(vehicle.getPurchase_date()));
			preparedStatement.setFloat(3, vehicle.getVehiclePrice());
			preparedStatement.setString(4, vehicle.getCity());

			recordInserted = preparedStatement.executeUpdate();
		} catch (SQLException e) {
			throw new CustomException("Error while inserting values::"
					+ e.getMessage());
		}
		return recordInserted;
	}

	@Override
	public int deleteVehicle(Vehicle vehicle) throws CustomException {
		connection = DBUtil.obtainConnection();
		int id=0;
		String sql = "DELETE FROM vehicle WHERE vehicleid=?";
		try {
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, vehicle.getVehicleId());
			 id = preparedStatement.executeUpdate();
		} catch (SQLException e) {
			throw new CustomException("Error while deleting values::"
					+ e.getMessage());
		}
		return id;
	}

}
