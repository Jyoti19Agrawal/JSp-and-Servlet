package com.cg.session.form;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/session1")
public class FormServlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public FormServlet1() {
		super();

	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		 
		String uname  = request.getParameter("userName");
		String upswd  = request.getParameter("userPswd");
		String country = "India";
		PrintWriter out = response.getWriter();
		if(uname.equals("Jyoti") && upswd.equals("agrawal")){
			HttpSession session = request.getSession();
			String sessionId = session.getId();
			out.print("Session Id is " + sessionId);
			out.print("<br/>");
			session.setAttribute("uName", uname);
			session.setAttribute("uCountry", country);
			RequestDispatcher rd = request.getRequestDispatcher("/session2");
			rd.forward(request, response);
			//out.print("<a href ='session2'>See your Detail</a>");
			/*out.print("<form action='session2' method='post'>");
			out.print("<input type='submit'>");
			out.print("</form>");*/
			out.close();
		}
		else
		{
			out.println("Sorry UserName or Password Error! Enter Again !!!");
			RequestDispatcher rd=request.getRequestDispatcher("/Index.html");
			rd.include(request, response);
		}
		
	}

}
