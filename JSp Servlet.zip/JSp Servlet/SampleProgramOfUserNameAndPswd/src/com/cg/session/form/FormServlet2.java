package com.cg.session.form;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/session2")
public class FormServlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public FormServlet2() {
		super();

	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession(false);
		String n = (String) session.getAttribute("uName");
		String p = (String) session.getAttribute("uCountry");
		 
		out.print("Hello&lt;&lt;" + n + "&gt;&gt;,Welcome to&lt;&lt;" +p+"&gt;&gt;");
		out.print("<br/>");
		String sessionId = session.getId();
		out.print("session Id is " + sessionId);
		out.close();
	}

}
